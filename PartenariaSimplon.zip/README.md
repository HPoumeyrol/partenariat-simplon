# Partenariat Simplon
## Une Simple Extention WordPress

### Description :

Ce Plugin a pour mission de simplifier l'insertion dans vos articles de la mention du partenariat avec simplon :

"La publication de cet article est possible grâce à mon super partenaire simplon.co - une entreprise de
l’économie sociale et solidaire et un réseau de « fabriques » (écoles) qui propose
des formations GRATUITES pour devenir développeur web."

Il suffirat d'utiliser un shortcode [SimplonParteriat]

### Installation :

Dans le menu Exteionsions de Wordpress, cliquez sur ajouter.
Cliquez sur Télverser une extension
Sélectionnez le fichier zip contenant votre extension.
Cliquez sur Installer
Cliquez sur Activer

Vous pouvez ensuite utiliser le shortcode dans vos articles.

### Utilisation :

Insérez dans vos articles, a l'emplacement désiré, le short code [SimplonParteriat]

### Ressources :
#### Déclaration du plugin :
https://openclassrooms.com/courses/propulsez-votre-site-avec-wordpress/creer-des-plugins#r-1892278  
https://developer.wordpress.org/plugins/the-basics/header-requirements/

#### Shortcodes :
https://www.sitepoint.com/wordpress-shortcodes-tutorial/ - chapitre Simple Shortcodes 
